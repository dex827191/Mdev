package com.mdevz.sp.ui.logs

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mdevz.sp.databinding.ActivityLogsBinding
import com.mdevz.sp.service.TunnelRuntime
import kotlinx.coroutines.launch

class LogsActivity : AppCompatActivity() {

    private var _binding:
        ActivityLogsBinding? = null

    private val binding:
        ActivityLogsBinding
        get() = requireNotNull(_binding)

    private var controller:
        LogsController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bindingValue = ActivityLogsBinding.inflate(layoutInflater)
        _binding = bindingValue
        setContentView(bindingValue.root)
        binding.toolbarLogs.setNavigationOnClickListener { finish() }
        val runtime = TunnelRuntime.get(this)
        val logsController = LogsController(context = this, binding = binding, logger = runtime.logger)
        controller = logsController
        logsController.setup()
        lifecycleScope.launch { repeatOnLifecycle(Lifecycle.State.STARTED) { runtime.logger.entries.collect { logsController.render(it) } } }
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        _binding = null
        super.onDestroy()
    }
}

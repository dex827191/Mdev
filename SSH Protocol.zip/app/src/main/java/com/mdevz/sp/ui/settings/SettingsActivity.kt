package com.mdevz.sp.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import com.mdevz.sp.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private var _binding:
        ActivitySettingsBinding? = null

    private val binding:
        ActivitySettingsBinding
        get() = requireNotNull(_binding)

    private var controller:
        SettingsController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bindingValue = ActivitySettingsBinding.inflate(layoutInflater)
        _binding = bindingValue
        setContentView(bindingValue.root)
        controller = SettingsController(context = this, binding = binding)
        controller?.setup()
        binding.buttonAbout.setOnClickListener { startActivity(Intent(this, com.mdevz.sp.ui.about.AboutActivity::class.java)) }
    }

    override fun onDestroy() {
        controller = null
        _binding = null
        super.onDestroy()
    }
}

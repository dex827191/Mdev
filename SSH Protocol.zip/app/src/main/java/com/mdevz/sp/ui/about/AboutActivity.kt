package com.mdevz.sp.ui.about

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mdevz.sp.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    private var _binding:
        ActivityAboutBinding? = null

    private val binding:
        ActivityAboutBinding
        get() = requireNotNull(_binding)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bindingValue = ActivityAboutBinding.inflate(layoutInflater)
        _binding = bindingValue
        setContentView(bindingValue.root)
        binding.toolbarAbout.setNavigationOnClickListener { finish() }
    }

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
    }
}

package com.mdevz.sp.service

import android.content.Context
import com.mdevz.sp.core.config.SharedPreferencesProfileRepository
import com.mdevz.sp.core.config.YamlProfileRepository
import com.mdevz.sp.ssh.SharedPreferencesKnownHostStore
import com.mdevz.sp.tunnel.MemoryTunnelLogger
import com.mdevz.sp.tunnel.TunnelEngine
import com.mdevz.sp.vpn.VpnProtectBridge

class TunnelRuntime private constructor(
    context: Context
) {

    private val appContext =
        context.applicationContext

    val logger =
        MemoryTunnelLogger()

    val knownHosts =
        SharedPreferencesKnownHostStore(
            appContext
        )

    // Import existing profiles once, then use YAML files as the sole profile store.
    val profiles = YamlProfileRepository(appContext).also { yamlRepository ->
        runCatching {
            val legacy = SharedPreferencesProfileRepository(appContext)
            if (yamlRepository.listIds().isEmpty()) {
                legacy.listIds().forEach { id ->
                    legacy.load(id)?.let { yamlRepository.save(id, it) }
                }
            }
        }
    }

    val vpnProtectBridge =
        VpnProtectBridge()

    val engine =
        TunnelEngine(
            knownHostStore = knownHosts,
            vpnProtectBridge =
                vpnProtectBridge,
            logger = logger
        )

    companion object {
        @Volatile
        private var instance:
            TunnelRuntime? = null

        fun get(
            context: Context
        ): TunnelRuntime =
            instance
                ?: synchronized(this) {
                    instance
                        ?: TunnelRuntime(
                            context.applicationContext
                        ).also {
                            instance = it
                        }
                }
    }
}

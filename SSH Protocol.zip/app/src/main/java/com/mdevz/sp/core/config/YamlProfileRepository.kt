package com.mdevz.sp.core.config

import android.content.Context
import com.mdevz.sp.core.model.PayloadMode
import com.mdevz.sp.core.model.SshProfile
import org.yaml.snakeyaml.DumperOptions
import org.yaml.snakeyaml.LoaderOptions
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.SafeConstructor
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.Base64

/** Stores each SSH profile as a human-readable YAML file in files/profiles. */
class YamlProfileRepository(context: Context) : ProfileRepository {
    private val directory = File(context.applicationContext.filesDir, "profiles").apply { mkdirs() }
    private val loader = Yaml(SafeConstructor(LoaderOptions()))
    private val dumper = Yaml(DumperOptions().apply {
        defaultFlowStyle = DumperOptions.FlowStyle.BLOCK
        isPrettyFlow = true
        indent = 2
        indicatorIndent = 0
        width = 120
    })

    @Synchronized
    override fun save(id: String, profile: SshProfile) {
        require(id.isNotBlank()) { "Profile id must not be blank" }
        val data = linkedMapOf<String, Any?>(
            "schema" to "ssh-protocol/v1",
            "name" to profile.name,
            "connection" to linkedMapOf(
                "type" to "ssh",
                "host" to profile.sshHost,
                "port" to profile.sshPort,
                "username" to profile.username,
                "password" to profile.password
            ),
            "payload" to linkedMapOf(
                "enabled" to profile.payloadEnabled,
                "mode" to profile.payloadMode.name.lowercase(),
                "content" to profile.payload
            ),
            "proxy" to linkedMapOf(
                "enabled" to profile.proxyEnabled,
                "host" to profile.proxyHost,
                "port" to profile.proxyPort
            ),
            "tls" to linkedMapOf(
                "enabled" to profile.tlsEnabled,
                "sni" to profile.sni,
                "version" to profile.tlsVersion
            ),
            "tunnel" to linkedMapOf(
                "type" to "socks5",
                "local-port" to profile.localSocksPort
            ),
            "transport" to linkedMapOf(
                "keep-alive-seconds" to profile.keepAliveSeconds,
                "send-buffer-size" to profile.socketSendBufferSize,
                "receive-buffer-size" to profile.socketReceiveBufferSize,
                "tcp-no-delay" to profile.tcpNoDelay,
                "connect-timeout-ms" to profile.connectTimeoutMillis,
                "read-timeout-ms" to profile.readTimeoutMillis
            ),
            "reconnect" to linkedMapOf(
                "enabled" to profile.autoReconnect,
                "max-attempts" to profile.maxReconnect
            ),
            "power" to linkedMapOf("cpu-wake-lock" to profile.cpuWakeLockEnabled)
        )
        val target = fileFor(id)
        val temp = File(directory, target.name + ".tmp")
        temp.writeText(dumper.dump(data), StandardCharsets.UTF_8)
        if (target.exists() && !target.delete()) throw IllegalStateException("Cannot replace profile YAML")
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
    }

    @Synchronized
    override fun load(id: String): SshProfile? {
        val file = fileFor(id)
        if (!file.isFile) return null
        val root = loader.load<Any?>(file.readText(StandardCharsets.UTF_8)) as? Map<*, *> ?: return null
        val connection = root.map("connection")
        val payload = root.map("payload")
        val proxy = root.map("proxy")
        val tls = root.map("tls")
        val tunnel = root.map("tunnel")
        val transport = root.map("transport")
        val reconnect = root.map("reconnect")
        val power = root.map("power")
        return SshProfile(
            name = root.string("name"),
            sshHost = connection.string("host"),
            sshPort = connection.int("port", 22),
            username = connection.string("username"),
            password = connection.string("password"),
            payloadEnabled = payload.bool("enabled", false),
            payloadMode = runCatching { PayloadMode.valueOf(payload.string("mode", "normal").uppercase()) }.getOrDefault(PayloadMode.NORMAL),
            payload = payload.string("content"),
            proxyEnabled = proxy.bool("enabled", false),
            proxyHost = proxy.string("host"),
            proxyPort = proxy.int("port", 0),
            tlsEnabled = tls.bool("enabled", false),
            sni = tls.string("sni"),
            tlsVersion = tls.string("version", "default"),
            localSocksPort = tunnel.int("local-port", 1080),
            keepAliveSeconds = transport.int("keep-alive-seconds", 30),
            socketSendBufferSize = transport.int("send-buffer-size", 16_384),
            socketReceiveBufferSize = transport.int("receive-buffer-size", 32_768),
            tcpNoDelay = transport.bool("tcp-no-delay", true),
            cpuWakeLockEnabled = power.bool("cpu-wake-lock", false),
            connectTimeoutMillis = transport.int("connect-timeout-ms", 15_000),
            readTimeoutMillis = transport.int("read-timeout-ms", 0),
            autoReconnect = reconnect.bool("enabled", true),
            maxReconnect = reconnect.int("max-attempts", 0)
        )
    }

    @Synchronized
    override fun delete(id: String) { fileFor(id).delete() }

    @Synchronized
    override fun listIds(): List<String> = directory.listFiles()
        ?.filter { it.isFile && it.extension == "yaml" }
        ?.mapNotNull { file -> runCatching { String(Base64.getUrlDecoder().decode(file.nameWithoutExtension), StandardCharsets.UTF_8) }.getOrNull() }
        ?.sorted().orEmpty()

    private fun fileFor(id: String): File {
        val encoded = Base64.getUrlEncoder().withoutPadding().encodeToString(id.toByteArray(StandardCharsets.UTF_8))
        return File(directory, "$encoded.yaml")
    }

    private fun Map<*, *>.map(key: String): Map<*, *> = this[key] as? Map<*, *> ?: emptyMap<Any, Any>()
    private fun Map<*, *>.string(key: String, default: String = ""): String = this[key]?.toString() ?: default
    private fun Map<*, *>.int(key: String, default: Int): Int = (this[key] as? Number)?.toInt() ?: this[key]?.toString()?.toIntOrNull() ?: default
    private fun Map<*, *>.bool(key: String, default: Boolean): Boolean = this[key] as? Boolean ?: default
}

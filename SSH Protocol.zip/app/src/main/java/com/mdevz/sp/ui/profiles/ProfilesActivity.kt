package com.mdevz.sp.ui.profiles

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.widget.EditText
import android.widget.Toast
import android.widget.PopupMenu
import androidx.core.view.isVisible
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.mdevz.sp.R
import com.mdevz.sp.core.model.SshProfile
import com.mdevz.sp.databinding.ActivityProfilesBinding
import com.mdevz.sp.databinding.ItemProfileGridBinding
import com.mdevz.sp.databinding.ItemProfileListBinding
import com.mdevz.sp.service.TunnelRuntime
import com.mdevz.sp.ui.editor.ProfileEditorActivity
import java.util.UUID

class ProfilesActivity : AppCompatActivity() {


    private enum class ProfileFilter {
        ALL,
        FAVORITE,
        PINNED,
        ACTIVE
    }

    private var profileFilter =
        ProfileFilter.ALL

    private var _binding:
        ActivityProfilesBinding? = null

    private val binding:
        ActivityProfilesBinding
        get() = requireNotNull(_binding)

    private lateinit var runtime:
        TunnelRuntime

    private lateinit var adapter:
        ProfileAdapter

    private var allProfiles:
        List<ProfileEntry> = emptyList()

    private var query:
        String = ""

    private var gridMode:
        Boolean = false

    private var favoriteProfileIds:
        Set<String> = emptySet()

    private var pinnedProfileIds:
        Set<String> = emptySet()

    private var activeProfileId:
        String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bindingValue = ActivityProfilesBinding.inflate(layoutInflater)
        _binding = bindingValue
        setContentView(bindingValue.root)

        runtime = TunnelRuntime.get(this)
        val preferences = getSharedPreferences(PROFILE_UI_PREFERENCES, Context.MODE_PRIVATE)
        gridMode = preferences.getBoolean(KEY_GRID_MODE, false)
        favoriteProfileIds = preferences.getStringSet(KEY_FAVORITE_PROFILE_IDS, emptySet())?.toSet().orEmpty()
        pinnedProfileIds = preferences.getStringSet(KEY_PINNED_PROFILE_IDS, emptySet())?.toSet().orEmpty()
        activeProfileId = preferences.getString(KEY_ACTIVE_PROFILE, null)
        adapter = ProfileAdapter(onOpen = ::openEditor, onMenu = ::showProfileMenu)
        binding.listProfiles.adapter = adapter
        applyLayoutManager()
        binding.toolbarProfiles.setNavigationOnClickListener { finish() }
        binding.buttonViewMode.setOnClickListener {
            gridMode = !gridMode
            preferences.edit().putBoolean(KEY_GRID_MODE, gridMode).apply()
            applyLayoutManager(); render()
        }
        binding.buttonImportProfiles.setOnClickListener { showImportClipboardDialog() }
        binding.buttonProfileFilter.setOnClickListener { showFilterMenu() }
        binding.buttonAddProfile.setOnClickListener { createProfile() }
        binding.buttonCreateProfile.setOnClickListener { createProfile() }
        binding.inputProfileSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString()?.trim().orEmpty(); render() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        reloadProfiles()
    }

    override fun onResume() { super.onResume(); if (::adapter.isInitialized) reloadProfiles() }

    override fun onDestroy() {
        if (::adapter.isInitialized) binding.listProfiles.adapter = null
        _binding = null
        super.onDestroy()
    }

    private fun reloadProfiles() {
        allProfiles =
            runtime.profiles
                .listIds()
                .mapNotNull {
                    id ->
                    runtime.profiles
                        .load(id)
                        ?.let {
                            profile ->
                            ProfileEntry(
                                id = id,
                                profile = profile
                            )
                        }
                }
                .sortedWith(
                    compareByDescending<ProfileEntry> {
                        it.id ==
                            activeProfileId
                    }.thenByDescending {
                        pinnedProfileIds.contains(
                            it.id
                        )
                    }.thenByDescending {
                        favoriteProfileIds.contains(
                            it.id
                        )
                    }.thenBy {
                        it.profile.name
                            .lowercase()
                    }.thenBy {
                        it.id
                    }
                )

        if (
            activeProfileId != null &&
            allProfiles.none {
                it.id ==
                    activeProfileId
            }
        ) {
            activeProfileId = null

            this
                .getSharedPreferences(
                    PROFILE_UI_PREFERENCES,
                    Context.MODE_PRIVATE
                )
                .edit()
                .remove(
                    KEY_ACTIVE_PROFILE
                )
                .apply()
        }

        render()
    }


    private fun showFilterMenu() {
        val popup =
            PopupMenu(
                this,
                binding.buttonProfileFilter
            )

        popup.menu.add(
            R.string.profiles_filter_all
        ).setOnMenuItemClickListener {
            setProfileFilter(
                ProfileFilter.ALL
            )
            true
        }

        popup.menu.add(
            R.string.profiles_filter_favorite
        ).setOnMenuItemClickListener {
            setProfileFilter(
                ProfileFilter.FAVORITE
            )
            true
        }

        popup.menu.add(
            R.string.profiles_filter_pinned
        ).setOnMenuItemClickListener {
            setProfileFilter(
                ProfileFilter.PINNED
            )
            true
        }

        popup.menu.add(
            R.string.profiles_filter_active
        ).setOnMenuItemClickListener {
            setProfileFilter(
                ProfileFilter.ACTIVE
            )
            true
        }

        popup.show()
    }

    private fun setProfileFilter(
        filter: ProfileFilter
    ) {
        profileFilter = filter

        binding.buttonProfileFilter.setText(
            when (filter) {
                ProfileFilter.ALL ->
                    R.string.profiles_filter_all

                ProfileFilter.FAVORITE ->
                    R.string.profiles_filter_favorite

                ProfileFilter.PINNED ->
                    R.string.profiles_filter_pinned

                ProfileFilter.ACTIVE ->
                    R.string.profiles_filter_active
            }
        )

        render()
    }

    private fun matchesProfileFilter(
        entry: ProfileEntry
    ): Boolean =
        when (profileFilter) {
            ProfileFilter.ALL ->
                true

            ProfileFilter.FAVORITE ->
                favoriteProfileIds.contains(
                    entry.id
                )

            ProfileFilter.PINNED ->
                pinnedProfileIds.contains(
                    entry.id
                )

            ProfileFilter.ACTIVE ->
                entry.id == activeProfileId
        }

    private fun render() {
        val normalizedQuery =
            query.lowercase()

        val searchVisible =
            if (normalizedQuery.isBlank()) {
                allProfiles
            } else {
                allProfiles.filter {
                    entry ->
                    entry.profile.name
                        .lowercase()
                        .contains(
                            normalizedQuery
                        ) ||
                        entry.profile.sshHost
                            .lowercase()
                            .contains(
                                normalizedQuery
                            )
                }
            }

        val visible =
            searchVisible.filter {
                entry ->
                matchesProfileFilter(
                    entry
                )
            }

        adapter.submit(
            entries = visible,
            gridMode = gridMode,
            activeProfileId =
                activeProfileId
        )

        binding.profileEmptyState.isVisible =
            allProfiles.isEmpty()

        binding.listProfiles.isVisible =
            allProfiles.isNotEmpty()

        binding.buttonViewMode.text =
            getString(
                if (gridMode) {
                    R.string.profiles_list_view
                } else {
                    R.string.profiles_grid_view
                }
            )
    }

    private fun applyLayoutManager() {
        binding.listProfiles.layoutManager =
            if (gridMode) {
                GridLayoutManager(
                    this,
                    GRID_SPAN_COUNT
                )
            } else {
                LinearLayoutManager(
                    this
                )
            }
    }

    private fun createProfile() {
        val id =
            UUID.randomUUID()
                .toString()

        runtime.profiles.save(
            id,
            SshProfile(
                name = "",
                sshHost = "",
                username = "",
                password = ""
            )
        )

        openEditor(id)
    }

    private fun openEditor(
        id: String
    ) {
        startActivity(Intent(this, com.mdevz.sp.ui.editor.ProfileEditorActivity::class.java).putExtra(ProfileEditorActivity.EXTRA_PROFILE_ID, id))
    }

    private fun showProfileMenu(
        anchor: View,
        entry: ProfileEntry
    ) {
        val popup =
            PopupMenu(
                this,
                anchor
            )

        popup.menu.add(
            R.string.action_edit
        ).setOnMenuItemClickListener {
            openEditor(entry.id)
            true
        }

        popup.menu.add(
            R.string.profile_set_active
        ).setOnMenuItemClickListener {
            setActive(entry.id)
            true
        }

        popup.menu.add(
            if (
                favoriteProfileIds.contains(
                    entry.id
                )
            ) {
                R.string.profile_remove_favorite
            } else {
                R.string.profile_add_favorite
            }
        ).setOnMenuItemClickListener {
            toggleFavorite(entry.id)
            true
        }

        popup.menu.add(
            if (
                pinnedProfileIds.contains(
                    entry.id
                )
            ) {
                R.string.profile_unpin
            } else {
                R.string.profile_pin
            }
        ).setOnMenuItemClickListener {
            togglePinned(entry.id)
            true
        }

        popup.menu.add(
            R.string.profile_duplicate
        ).setOnMenuItemClickListener {
            duplicate(entry)
            true
        }

        popup.menu.add(
            R.string.profile_export
        ).setOnMenuItemClickListener {
            exportProfileToClipboard(entry)
            true
        }

        popup.menu.add(
            R.string.profile_delete
        ).setOnMenuItemClickListener {
            confirmDelete(entry)
            true
        }

        popup.show()
    }

    private fun toggleFavorite(
        id: String
    ) {
        favoriteProfileIds =
            if (favoriteProfileIds.contains(id)) {
                favoriteProfileIds - id
            } else {
                favoriteProfileIds + id
            }

        this
            .getSharedPreferences(
                PROFILE_UI_PREFERENCES,
                Context.MODE_PRIVATE
            )
            .edit()
            .putStringSet(
                KEY_FAVORITE_PROFILE_IDS,
                favoriteProfileIds
            )
            .apply()

        reloadProfiles()
    }

    private fun togglePinned(
        id: String
    ) {
        pinnedProfileIds =
            if (pinnedProfileIds.contains(id)) {
                pinnedProfileIds - id
            } else {
                pinnedProfileIds + id
            }

        this
            .getSharedPreferences(
                PROFILE_UI_PREFERENCES,
                Context.MODE_PRIVATE
            )
            .edit()
            .putStringSet(
                KEY_PINNED_PROFILE_IDS,
                pinnedProfileIds
            )
            .apply()

        reloadProfiles()
    }

    private fun setActive(
        id: String
    ) {
        activeProfileId =
            id

        this
            .getSharedPreferences(
                PROFILE_UI_PREFERENCES,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_ACTIVE_PROFILE,
                id
            )
            .apply()

        reloadProfiles()
    }


    private fun showImportClipboardDialog() {
        val clipboard = this.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clipboardText = if (clipboard.hasPrimaryClip()) {
            clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        } else ""

        val input = EditText(this).apply {
            setText(clipboardText)
            hint = "Tempel konfigurasi YAML di sini"
            minLines = 8
            maxLines = 16
            setHorizontallyScrolling(false)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            textSize = 13f
            setPadding(40, 24, 40, 24)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.profile_import)
            .setMessage(R.string.profile_import_clipboard_hint)
            .setView(input)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.profile_import) { _, _ ->
                importYamlText(input.text?.toString().orEmpty())
            }
            .show()
    }

    private fun importYamlText(text: String) {
        val result = runCatching {
            val profile = runtime.profiles.decodeYaml(text)
            runtime.profiles.save(UUID.randomUUID().toString(), profile)
        }
        if (result.isSuccess) {
            reloadProfiles()
            Toast.makeText(this, R.string.profile_imported, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(
                this,
                getString(R.string.unable_import_profile) + ": " + (result.exceptionOrNull()?.message ?: "YAML tidak valid"),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun exportProfileToClipboard(entry: ProfileEntry) {
        val result = runCatching {
            val yaml = runtime.profiles.encodeYaml(entry.profile)
            val clipboard = this.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(
                ClipData.newPlainText("SSH Protocol YAML", yaml)
            )
        }
        Toast.makeText(
            this,
            if (result.isSuccess) R.string.profile_yaml_copied else R.string.profile_export_failed,
            Toast.LENGTH_LONG
        ).show()
    }

    private fun duplicate(
        entry: ProfileEntry
    ) {
        val newId =
            UUID.randomUUID()
                .toString()

        val source =
            entry.profile

        runtime.profiles.save(
            newId,
            source.copy(
                name =
                    getString(
                        R.string.profile_copy_name,
                        source.name
                            .ifBlank {
                                getString(
                                    R.string.profile_fallback_name
                                )
                            }
                    )
            )
        )

        reloadProfiles()
    }

    private fun confirmDelete(
        entry: ProfileEntry
    ) {
        MaterialAlertDialogBuilder(
            this
        )
            .setTitle(
                R.string.delete_profile_title
            )
            .setMessage(
                getString(
                    R.string.profile_delete_confirm,
                    entry.profile.name
                        .ifBlank {
                            getString(
                                R.string.profile_fallback_name
                            )
                        }
                )
            )
            .setNegativeButton(
                R.string.action_cancel,
                null
            )
            .setPositiveButton(
                R.string.profile_delete
            ) {
                _,
                _ ->
                deleteProfile(entry.id)
            }
            .show()
    }

    private fun deleteProfile(
        id: String
    ) {
        runtime.profiles.delete(id)

        if (activeProfileId == id) {
            activeProfileId = null

            this
                .getSharedPreferences(
                    PROFILE_UI_PREFERENCES,
                    Context.MODE_PRIVATE
                )
                .edit()
                .remove(
                    KEY_ACTIVE_PROFILE
                )
                .apply()
        }

        reloadProfiles()
    }

    private data class ProfileEntry(
        val id: String,
        val profile: SshProfile
    )

    private class ProfileAdapter(
        private val onOpen:
            (String) -> Unit,
        private val onMenu:
            (View, ProfileEntry) -> Unit
    ) : RecyclerView.Adapter<
        RecyclerView.ViewHolder
    >() {

        private val entries =
            mutableListOf<ProfileEntry>()

        private var gridMode =
            false

        private var activeProfileId:
            String? = null

        fun submit(
            entries: List<ProfileEntry>,
            gridMode: Boolean,
            activeProfileId: String?
        ) {
            this.entries.clear()
            this.entries.addAll(entries)
            this.gridMode = gridMode
            this.activeProfileId =
                activeProfileId

            notifyDataSetChanged()
        }

        override fun getItemViewType(
            position: Int
        ): Int =
            if (gridMode) {
                VIEW_GRID
            } else {
                VIEW_LIST
            }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): RecyclerView.ViewHolder =
            if (viewType == VIEW_GRID) {
                GridHolder(
                    ItemProfileGridBinding.inflate(
                        LayoutInflater.from(
                            parent.context
                        ),
                        parent,
                        false
                    )
                )
            } else {
                ListHolder(
                    ItemProfileListBinding.inflate(
                        LayoutInflater.from(
                            parent.context
                        ),
                        parent,
                        false
                    )
                )
            }

        override fun onBindViewHolder(
            holder: RecyclerView.ViewHolder,
            position: Int
        ) {
            val entry =
                entries[position]

            when (holder) {
                is ListHolder ->
                    holder.bind(
                        entry,
                        entry.id ==
                            activeProfileId
                    )

                is GridHolder ->
                    holder.bind(
                        entry,
                        entry.id ==
                            activeProfileId
                    )
            }
        }

        override fun getItemCount(): Int =
            entries.size

        private inner class ListHolder(
            private val binding:
                ItemProfileListBinding
        ) : RecyclerView.ViewHolder(
            binding.root
        ) {

            fun bind(
                entry: ProfileEntry,
                active: Boolean
            ) {
                binding.textProfileName.text =
                    entry.profile.name
                        .ifBlank {
                            itemView.context
                                .getString(
                                    R.string.profile_fallback_name
                                )
                        }

                binding.textProfileHost.text =
                    entry.profile.sshHost
                        .ifBlank {
                            itemView.context
                                .getString(
                                    R.string.ssh_host_not_set
                                )
                        }

                binding.textProfileActive
                    .isVisible =
                    active

                binding.root
                    .setOnClickListener {
                        onOpen(entry.id)
                    }

                binding.buttonProfileMenu
                    .setOnClickListener {
                        onMenu(it, entry)
                    }
            }
        }

        private inner class GridHolder(
            private val binding:
                ItemProfileGridBinding
        ) : RecyclerView.ViewHolder(
            binding.root
        ) {

            fun bind(
                entry: ProfileEntry,
                active: Boolean
            ) {
                binding.textProfileName.text =
                    entry.profile.name
                        .ifBlank {
                            itemView.context
                                .getString(
                                    R.string.profile_fallback_name
                                )
                        }

                binding.textProfileHost.text =
                    entry.profile.sshHost
                        .ifBlank {
                            itemView.context
                                .getString(
                                    R.string.ssh_host_not_set
                                )
                        }

                binding.textProfileActive
                    .isVisible =
                    active

                binding.root
                    .setOnClickListener {
                        onOpen(entry.id)
                    }

                binding.buttonProfileMenu
                    .setOnClickListener {
                        onMenu(it, entry)
                    }
            }
        }

        private companion object {
            const val VIEW_LIST =
                1

            const val VIEW_GRID =
                2
        }
    }

    private companion object {
        const val PROFILE_UI_PREFERENCES =
            "profile_ui_preferences"

        const val KEY_GRID_MODE =
            "grid_mode"

        const val KEY_FAVORITE_PROFILE_IDS =
            "favorite_profile_ids"

        const val KEY_PINNED_PROFILE_IDS =
            "pinned_profile_ids"

        const val KEY_ACTIVE_PROFILE =
            "active_profile_id"

        const val GRID_SPAN_COUNT =
            2
    }
}

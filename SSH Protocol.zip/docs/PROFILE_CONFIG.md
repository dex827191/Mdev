# SSH profile YAML

Profiles are stored in the app's private files directory (`files/profiles/`), one `.yaml` file per profile. The format is `ssh-protocol/v1`; see `examples/ssh-profile.yaml`.

The Android UI is implemented with XML layouts and ViewBinding. Kotlin remains responsible for app logic, SSH authentication, and tunnel runtime. The profile repository now reads and writes YAML. Existing profiles in the old SharedPreferences profile store are imported into YAML once when the YAML profile directory is empty.

**Credential note:** the YAML `connection.password` value is currently stored as plain text inside Android's private app storage. Do not export or share profile YAML files without removing or changing the password. App-private storage is sandboxed by Android, but the value is not encrypted by this repository.

Other non-profile preferences (for example UI preferences and known-host records) still use their existing storage implementations; this change replaces SharedPreferences specifically as the profile/configuration repository.

## Clipboard transfer

Profile export copies the custom YAML text to the Android clipboard. Profile import opens a multiline editor prefilled with the current clipboard text; review or paste the YAML, then confirm to create a new profile. The profile list and Home profile actions use the same clipboard export behavior. The YAML contains `connection.password`, so clipboard contents may be visible to other apps or remain available in clipboard history; clear the clipboard after transferring credentials on shared devices.
